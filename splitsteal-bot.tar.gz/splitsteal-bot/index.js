import express from "express";
import { webcrypto } from "crypto";

const app = express();
const PORT = process.env.PORT || 3000;

const PUBLIC_KEY = process.env.DISCORD_PUBLIC_KEY ?? "";
const BOT_TOKEN = process.env.DISCORD_BOT_TOKEN ?? "";
const APPLICATION_ID = process.env.DISCORD_APPLICATION_ID ?? "";
const GUILD_ID = process.env.DISCORD_GUILD_ID ?? "";
const OWNER_ID = process.env.DISCORD_OWNER_ID ?? "";

const DISCORD_API = "https://discord.com/api/v10";

const InteractionType = { PING: 1, APPLICATION_COMMAND: 2, MESSAGE_COMPONENT: 3 };
const ResponseType = {
  PONG: 1,
  CHANNEL_MESSAGE_WITH_SOURCE: 4,
  DEFERRED_CHANNEL_MESSAGE_WITH_SOURCE: 5,
  UPDATE_MESSAGE: 7,
};
const EPHEMERAL = 64;
const ADMINISTRATOR = BigInt(0x8);
const VIEW_CHANNEL = BigInt(1024);
const SEND_MESSAGES = BigInt(2048);
const READ_MESSAGE_HISTORY = BigInt(65536);
const ATTACH_FILES = BigInt(32768);

const games = new Map();

async function verifySignature(publicKeyHex, signature, timestamp, rawBody) {
  try {
    const key = await webcrypto.subtle.importKey(
      "raw",
      Buffer.from(publicKeyHex, "hex"),
      { name: "Ed25519" },
      false,
      ["verify"]
    );
    return await webcrypto.subtle.verify(
      "Ed25519",
      key,
      Buffer.from(signature, "hex"),
      Buffer.from(timestamp + rawBody)
    );
  } catch {
    return false;
  }
}

function isAdmin(permissions) {
  if (!permissions) return false;
  try { return (BigInt(permissions) & ADMINISTRATOR) === ADMINISTRATOR; } catch { return false; }
}

function makeGameId(channelId, u1, u2) {
  return `${channelId}:${[u1, u2].sort().join(":")}`;
}

function splitStealButtons(gameId) {
  return [{ type: 1, components: [
    { type: 2, custom_id: `split:${gameId}`, label: "Split", style: 2 },
    { type: 2, custom_id: `steal:${gameId}`, label: "Steal", style: 4 },
  ]}];
}

function cap(s) { return s.charAt(0).toUpperCase() + s.slice(1); }

function buildResultPayload(game) {
  const c1 = game.choices[game.user1Id];
  const c2 = game.choices[game.user2Id];
  let description, color;
  if (c1 === "split" && c2 === "split") {
    description = `Both players chose **Split**\nboth share the **${game.forWhat}** equally!`;
    color = 0x57f287;
  } else if (c1 === "steal" && c2 === "split") {
    description = `**${game.user1Name}** stole the **${game.forWhat}** from **${game.user2Name}**!`;
    color = 0xed4245;
  } else if (c1 === "split" && c2 === "steal") {
    description = `**${game.user2Name}** stole the **${game.forWhat}** from **${game.user1Name}**!`;
    color = 0xed4245;
  } else {
    description = `Both players chose **Steal**\nnobody gets the **${game.forWhat}**!`;
    color = 0x5865f2;
  }
  return {
    content: "",
    embeds: [{ title: "Game Results", description, color,
      fields: [{ name: game.user1Name, value: cap(c1), inline: true }, { name: game.user2Name, value: cap(c2), inline: true }],
    }],
    components: [],
  };
}

async function botFetch(method, path, body) {
  return fetch(`${DISCORD_API}${path}`, {
    method,
    headers: { Authorization: `Bot ${BOT_TOKEN}`, "Content-Type": "application/json" },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
}

async function followUp(interactionToken, payload) {
  return fetch(`${DISCORD_API}/webhooks/${APPLICATION_ID}/${interactionToken}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
}

async function createInvestTicket(investorId, investorName, amount, interactionToken) {
  const safeUsername = investorName.toLowerCase().replace(/[^a-z0-9]/g, "-").slice(0, 50);
  const channelName = `invest-${safeUsername}`;
  const allowBits = String(VIEW_CHANNEL | SEND_MESSAGES | READ_MESSAGE_HISTORY | ATTACH_FILES);
  const denyBits = String(VIEW_CHANNEL);

  const permissionOverwrites = [
    { id: GUILD_ID, type: 0, deny: denyBits },
    { id: investorId, type: 1, allow: allowBits },
    { id: OWNER_ID, type: 1, allow: allowBits },
    { id: APPLICATION_ID, type: 1, allow: allowBits },
  ];

  try {
    const chanRes = await botFetch("POST", `/guilds/${GUILD_ID}/channels`, {
      name: channelName,
      type: 0,
      topic: `Investment ticket for ${investorName} — ${amount}`,
      permission_overwrites: permissionOverwrites,
    });

    if (!chanRes.ok) {
      const err = await chanRes.text();
      console.error("Failed to create invest channel", chanRes.status, err);
      await followUp(interactionToken, {
        content: "❌ Failed to create your investment channel. Make sure I have the **Manage Channels** permission.",
        flags: EPHEMERAL,
      });
      return;
    }

    const channel = await chanRes.json();

    await botFetch("POST", `/channels/${channel.id}/messages`, {
      content: `<@${investorId}> <@${OWNER_ID}>`,
      embeds: [{
        title: "💰 New Investment Request",
        description: `**${investorName}** wants to invest **${amount}**.\n\nPlease discuss the details here.`,
        color: 0xf1c40f,
        fields: [
          { name: "Investor", value: `<@${investorId}>`, inline: true },
          { name: "Amount", value: amount, inline: true },
        ],
      }],
    });

    await followUp(interactionToken, {
      content: `✅ Your investment ticket has been created in <#${channel.id}>!`,
      flags: EPHEMERAL,
    });
  } catch (err) {
    console.error("Error in createInvestTicket", err);
    await followUp(interactionToken, {
      content: "❌ Something went wrong creating your investment channel.",
      flags: EPHEMERAL,
    });
  }
}

// Raw body middleware for signature verification
app.use("/interactions", express.raw({ type: "*/*" }));
app.use(express.json());

app.get("/", (_req, res) => res.send("SplitSteal Bot is running!"));

app.post("/interactions", async (req, res) => {
  const signature = req.headers["x-signature-ed25519"];
  const timestamp = req.headers["x-signature-timestamp"];
  const rawBody = req.body.toString("utf-8");

  if (!signature || !timestamp) { res.status(401).send("Missing signature headers"); return; }

  const valid = await verifySignature(PUBLIC_KEY, signature, timestamp, rawBody);
  if (!valid) { res.status(401).send("Invalid request signature"); return; }

  const body = JSON.parse(rawBody);

  if (body.type === InteractionType.PING) { res.json({ type: ResponseType.PONG }); return; }

  if (body.type === InteractionType.APPLICATION_COMMAND) {
    const commandName = body.data?.name;

    if (commandName === "splitsteal") {
      if (!isAdmin(body.member?.permissions)) {
        res.json({ type: ResponseType.CHANNEL_MESSAGE_WITH_SOURCE, data: { content: "❌ Only administrators can start a Split or Steal game.", flags: EPHEMERAL } });
        return;
      }
      const opts = body.data.options ?? [];
      const user1Id = opts.find(o => o.name === "user1")?.value ?? "";
      const user2Id = opts.find(o => o.name === "user2")?.value ?? "";
      const forWhat = opts.find(o => o.name === "for_what")?.value ?? "something";
      const channelId = body.channel_id;
      const resolved = body.data.resolved;
      const user1Name = resolved?.members?.[user1Id]?.nick ?? resolved?.users?.[user1Id]?.global_name ?? resolved?.users?.[user1Id]?.username ?? "Player 1";
      const user2Name = resolved?.members?.[user2Id]?.nick ?? resolved?.users?.[user2Id]?.global_name ?? resolved?.users?.[user2Id]?.username ?? "Player 2";

      if (user1Id === user2Id) { res.json({ type: ResponseType.CHANNEL_MESSAGE_WITH_SOURCE, data: { content: "❌ The two players must be different users.", flags: EPHEMERAL } }); return; }

      const gameId = makeGameId(channelId, user1Id, user2Id);
      if (games.has(gameId)) { res.json({ type: ResponseType.CHANNEL_MESSAGE_WITH_SOURCE, data: { content: "❌ A game between these two players is already running here.", flags: EPHEMERAL } }); return; }

      games.set(gameId, { user1Id, user1Name, user2Id, user2Name, forWhat, choices: {} });
      setTimeout(() => games.delete(gameId), 10 * 60 * 1000);

      res.json({ type: ResponseType.CHANNEL_MESSAGE_WITH_SOURCE, data: {
        embeds: [{ title: "Split or Steal", color: 0x5865f2, description: `**${forWhat}** is up for grabs!\n\n<@${user1Id}> vs <@${user2Id}>\n\nChoices are **private** — the result is revealed only when both players have chosen.` }],
        components: splitStealButtons(gameId),
      }});
      return;
    }

    if (commandName === "invest") {
      const opts = body.data.options ?? [];
      const amount = opts.find(o => o.name === "amount")?.value ?? "unknown";
      const userId = body.member?.user?.id ?? body.user?.id ?? "";
      const userName = body.member?.nick ?? body.member?.user?.global_name ?? body.member?.user?.username ?? "Unknown";
      const interactionToken = body.token;

      res.json({ type: ResponseType.DEFERRED_CHANNEL_MESSAGE_WITH_SOURCE, data: { flags: EPHEMERAL } });
      setImmediate(() => createInvestTicket(userId, userName, amount, interactionToken));
      return;
    }
  }

  if (body.type === InteractionType.MESSAGE_COMPONENT) {
    const raw = body.data?.custom_id;
    const colonIdx = raw.indexOf(":");
    const choice = raw.slice(0, colonIdx);
    const gameId = raw.slice(colonIdx + 1);
    const userId = body.member?.user?.id ?? body.user?.id ?? "";
    const game = games.get(gameId);

    if (!game) { res.json({ type: ResponseType.CHANNEL_MESSAGE_WITH_SOURCE, data: { content: "❌ This game has expired or no longer exists.", flags: EPHEMERAL } }); return; }
    if (userId !== game.user1Id && userId !== game.user2Id) { res.json({ type: ResponseType.CHANNEL_MESSAGE_WITH_SOURCE, data: { content: "❌ You are not a participant in this game.", flags: EPHEMERAL } }); return; }
    if (game.choices[userId] !== undefined) { res.json({ type: ResponseType.CHANNEL_MESSAGE_WITH_SOURCE, data: { content: "⚠️ You have already made your choice! Waiting for the other player…", flags: EPHEMERAL } }); return; }

    game.choices[userId] = choice;
    const otherId = userId === game.user1Id ? game.user2Id : game.user1Id;
    const bothDone = game.choices[otherId] !== undefined;

    if (bothDone) {
      games.delete(gameId);
      res.json({ type: ResponseType.UPDATE_MESSAGE, data: buildResultPayload(game) });
    } else {
      res.json({ type: ResponseType.CHANNEL_MESSAGE_WITH_SOURCE, data: { content: `🤫 You chose **${cap(choice)}**. Waiting for the other player to decide…`, flags: EPHEMERAL } });
    }
    return;
  }

  res.status(400).json({ error: "Unhandled interaction type" });
});

app.listen(PORT, () => console.log(`SplitSteal Bot listening on port ${PORT}`));
